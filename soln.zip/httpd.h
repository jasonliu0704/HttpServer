#ifndef HTTPD_H
#define HTTPD_H

#include "Practical.h"

using namespace std;

void start_httpd(unsigned short port, char*  doc_root, char* service);

#endif // HTTPD_H
